<script>
    import { onMount } from "svelte";

    export let src;
    let imgc;

    var options = {
        width: 400,
        zoomWidth: 500,
        offset: { vertical: 0, horizontal: 10 },
        zoomPosition: "original",
    };
    onMount(() => {
        if (imgc)
        new ImageZoom(document.getElementById("img-container"), options);
    });
    const volver = () => {
        window.history.back();
    };
</script>

<div class="d-flex justify-content-center">
    <a href="#!" class="text-center" on:click|preventDefault={volver}>Volver</a>
</div>
<div class="d-flex justify-content-center">
    <img bind:this={imgc} {src} id="img-container" class="img-fluid" alt="..." />
</div>

<style>
</style>
